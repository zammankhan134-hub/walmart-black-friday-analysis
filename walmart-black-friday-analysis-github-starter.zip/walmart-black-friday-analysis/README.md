# Walmart Black Friday Sales Analysis — CLT & Confidence Intervals

## Project overview
This project analyzes customer purchase behavior during Walmart Black Friday sales. The main question is whether female customers spend more than male customers. The analysis also explores spending patterns across age groups and marital status.

## Dataset
The report describes transactional customer data with fields including:
- Gender
- Age
- Occupation
- City Category
- Marital Status
- Purchase amount

Each row represents a customer purchase. The report states that there were no significant missing values.

## Analysis performed
- Purchase distribution analysis
- Gender-wise purchase comparison
- Central Limit Theorem (CLT) using repeated samples and sample means
- Confidence intervals for male and female customers
- Marital-status comparison
- Age-group spending analysis
- Business recommendations based on observed patterns

## Key findings reported
- Purchase amounts are right-skewed: most purchases are lower, while a smaller number are high-value purchases.
- Male customers have a slightly higher average purchase than female customers, but the report describes the difference as small.
- The distribution of sample means is approximately normal, even though the original purchase distribution is skewed.
- The confidence intervals for male and female customers overlap; the report interprets this as no statistically significant difference in spending.
- Married customers tend to spend slightly more than unmarried customers.
- Customers aged 26–35 show higher spending than other age groups.

## Business recommendations in the report
1. Focus on the 26–35 age group with personalized offers and premium products.
2. Design marketing strategies for both male and female customers.
3. Consider family-oriented promotions for married customers.
4. Identify and reward high-value customers through loyalty programs.
5. Promote premium products to support revenue growth.

## Repository contents
- `README.md` — project overview, findings, and recommendations.
- `report/Walmart_Black_Friday_CLT_Confidence_Intervals_Report.pdf` — the original 10-page project report.

## Reproducibility note
This starter repository currently contains the report only. Add the original Jupyter Notebook (`.ipynb`) and dataset (`.csv`) to make the analysis reproducible. Check the dataset's license and terms before publishing it publicly.

## Author
Mohd Zamman Mohd Mubeen Khan
